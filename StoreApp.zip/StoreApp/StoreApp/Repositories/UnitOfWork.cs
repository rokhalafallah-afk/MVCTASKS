using StoreApp.Data;

namespace StoreApp.Repositories;

public class UnitOfWork : IUnitOfWork
{
    private readonly AppDbContext _context;

    // Constructor injection: the container supplies every dependency
    public UnitOfWork(AppDbContext context, IProductRepository products, ICategoryRepository categories)
    {
        _context = context;
        Products = products;
        Categories = categories;
    }

    public IProductRepository Products { get; }
    public ICategoryRepository Categories { get; }

    public Task<int> CompleteAsync() => _context.SaveChangesAsync();
}
