using Microsoft.EntityFrameworkCore;
using StoreApp.Data;
using StoreApp.Models;

namespace StoreApp.Repositories;

public class ProductRepository : Repository<Product>, IProductRepository
{
    public ProductRepository(AppDbContext context) : base(context) { }

    public async Task<IEnumerable<Product>> GetAllWithCategoryAsync() =>
        await Set.AsNoTracking().Include(p => p.Category).OrderBy(p => p.Name).ToListAsync();

    public async Task<Product?> GetByIdWithCategoryAsync(int id) =>
        await Set.Include(p => p.Category).FirstOrDefaultAsync(p => p.Id == id);

    public async Task<IEnumerable<Product>> GetByCategoryAsync(int categoryId) =>
        await Set.AsNoTracking().Include(p => p.Category)
                 .Where(p => p.CategoryId == categoryId).OrderBy(p => p.Name).ToListAsync();

    public async Task<IEnumerable<Product>> SearchAsync(string term) =>
        await Set.AsNoTracking().Include(p => p.Category)
                 .Where(p => p.Name.Contains(term)).OrderBy(p => p.Name).ToListAsync();

    public async Task<IEnumerable<Product>> GetByMonthAsync(int year, int? month)
    {
        var query = Set.AsNoTracking().Include(p => p.Category)
                       .Where(p => p.CreatedAt.Year == year);

        if (month.HasValue)
            query = query.Where(p => p.CreatedAt.Month == month.Value);

        return await query.OrderBy(p => p.CreatedAt).ToListAsync();
    }
}
