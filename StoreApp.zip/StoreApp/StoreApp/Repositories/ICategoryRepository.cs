using StoreApp.Models;

namespace StoreApp.Repositories;

public interface ICategoryRepository : IRepository<Category>
{
}
