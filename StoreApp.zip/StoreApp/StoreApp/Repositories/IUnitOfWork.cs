namespace StoreApp.Repositories;

/// <summary>
/// Groups repositories and commits all their changes in a single transaction.
/// Controllers depend on this abstraction only, never on EF Core.
/// </summary>
public interface IUnitOfWork
{
    IProductRepository Products { get; }
    ICategoryRepository Categories { get; }
    Task<int> CompleteAsync();
}
