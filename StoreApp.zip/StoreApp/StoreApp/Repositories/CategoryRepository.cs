using StoreApp.Data;
using StoreApp.Models;

namespace StoreApp.Repositories;

public class CategoryRepository : Repository<Category>, ICategoryRepository
{
    public CategoryRepository(AppDbContext context) : base(context) { }
}
