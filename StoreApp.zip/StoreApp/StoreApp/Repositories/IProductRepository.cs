using StoreApp.Models;

namespace StoreApp.Repositories;

/// <summary>Product-specific queries live here, not in controllers.</summary>
public interface IProductRepository : IRepository<Product>
{
    Task<IEnumerable<Product>> GetAllWithCategoryAsync();
    Task<Product?> GetByIdWithCategoryAsync(int id);
    Task<IEnumerable<Product>> GetByCategoryAsync(int categoryId);
    Task<IEnumerable<Product>> SearchAsync(string term);
    Task<IEnumerable<Product>> GetByMonthAsync(int year, int? month);
}
