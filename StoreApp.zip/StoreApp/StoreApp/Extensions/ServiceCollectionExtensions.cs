using Microsoft.EntityFrameworkCore;
using StoreApp.Data;
using StoreApp.Repositories;

namespace StoreApp.Extensions;

public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Composition root: the ONLY place that knows which concrete class implements which interface.
    /// </summary>
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration config)
    {
        // The connection string is NOT hard-coded. It comes from configuration, which is layered:
        //   appsettings.json < appsettings.{Env}.json < User Secrets (dev) < Environment variables < Key Vault
        var connectionString = config.GetConnectionString("DefaultConnection");

        if (string.IsNullOrWhiteSpace(connectionString))
            throw new InvalidOperationException(
                "Connection string 'DefaultConnection' was not found. " +
                "Set it with user-secrets (dev), an environment variable (ConnectionStrings__DefaultConnection) or Key Vault.");

        // Scoped = one DbContext per HTTP request
        services.AddDbContext<AppDbContext>(options => options.UseSqlServer(connectionString));

        // Repositories + Unit of Work, all scoped so they share the SAME DbContext in a request
        services.AddScoped<IProductRepository, ProductRepository>();
        services.AddScoped<ICategoryRepository, CategoryRepository>();
        services.AddScoped<IUnitOfWork, UnitOfWork>();

        return services;
    }
}
