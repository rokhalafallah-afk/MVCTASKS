using Microsoft.EntityFrameworkCore;
using StoreApp.Data;
using StoreApp.Extensions;

var builder = WebApplication.CreateBuilder(args);

// ---------------------------------------------------------------------------
// Task 4 / Approach 3 (optional): Azure Key Vault as an extra configuration source.
// Uncomment the packages in the .csproj, then:
//
// var vaultUri = builder.Configuration["KeyVault:Uri"];
// if (!string.IsNullOrEmpty(vaultUri))
//     builder.Configuration.AddAzureKeyVault(new Uri(vaultUri), new Azure.Identity.DefaultAzureCredential());
//
// A secret named "ConnectionStrings--DefaultConnection" maps to ConnectionStrings:DefaultConnection.
// ---------------------------------------------------------------------------

// MVC + anti-forgery header (used by the AJAX delete in the demo)
builder.Services.AddControllersWithViews();
builder.Services.AddAntiforgery(o => o.HeaderName = "RequestVerificationToken");

// Task 1: every dependency is registered in ONE place (composition root)
builder.Services.AddInfrastructure(builder.Configuration);

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/StatusCode?code=500");
    app.UseHsts();
}

// Turns any 404/403/... produced by NotFound() etc. into our friendly page
app.UseStatusCodePagesWithReExecute("/Home/StatusCode", "?code={0}");

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

// ---------------------------------------------------------------------------
// Task 2: custom routes. ORDER MATTERS: most specific first, generic last.
// ---------------------------------------------------------------------------

// 1) Constraints + optional parameter:   /archive/2026   or   /archive/2026/11
app.MapControllerRoute(
    name: "archive",
    pattern: "archive/{year:int:min(2000)}/{month:int:range(1,12)?}",
    defaults: new { controller = "Products", action = "Archive" });

// 2) Nested resource:   /category/2/products
app.MapControllerRoute(
    name: "products-by-category",
    pattern: "category/{categoryId:int}/products",
    defaults: new { controller = "Products", action = "ByCategory" });

// 3) SEO-friendly URL with optional slug:   /product/5   or   /product/5/mechanical-keyboard
app.MapControllerRoute(
    name: "product-details",
    pattern: "product/{id:int}/{slug?}",
    defaults: new { controller = "Products", action = "Details" });

// 4) Optional segment:   /search   or   /search/keyboard   (also /search?term=keyboard)
app.MapControllerRoute(
    name: "search",
    pattern: "search/{term?}",
    defaults: new { controller = "Products", action = "Search" });

// 5) Conventional default route (controller/action/id) with defaults
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

// 6) Catch-all: anything nothing else matched (e.g. /a/b/c/d/e) -> custom 404 page
app.MapControllerRoute(
    name: "catch-all",
    pattern: "{*url}",
    defaults: new { controller = "Home", action = "PageNotFound" });

// Dev convenience: create + seed the database without needing migrations.
// For real projects replace with: dotnet ef migrations add Init / dotnet ef database update
if (app.Environment.IsDevelopment())
{
    using var scope = app.Services.CreateScope();
    scope.ServiceProvider.GetRequiredService<AppDbContext>().Database.EnsureCreated();
}

app.Run();
