using Microsoft.AspNetCore.Mvc;

namespace StoreApp.Controllers;

public class HomeController : Controller
{
    public IActionResult Index() => View();

    // Target of the catch-all route {*url}
    public IActionResult PageNotFound(string? url)
    {
        Response.StatusCode = StatusCodes.Status404NotFound;
        ViewBag.Code = 404;
        ViewBag.Path = "/" + url;
        return View("StatusPage");
    }

    // Target of UseStatusCodePagesWithReExecute (404 from NotFound(), 500, ...)
    public IActionResult StatusCode(int code)
    {
        ViewBag.Code = code;
        return View("StatusPage");
    }
}
