using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using StoreApp.Models;
using StoreApp.Repositories;

namespace StoreApp.Controllers;

public class ProductsController : Controller
{
    private readonly IUnitOfWork _uow;

    // Dependency Injection: ASP.NET Core supplies IUnitOfWork (see AddInfrastructure)
    public ProductsController(IUnitOfWork uow) => _uow = uow;

    private bool IsAjax => Request.Headers["X-Requested-With"] == "XMLHttpRequest";

    // GET /Products
    public async Task<IActionResult> Index() =>
        View(await _uow.Products.GetAllWithCategoryAsync());

    // GET /search/keyboard  or  /search?term=keyboard   (route: "search")
    // Returns only the table rows for AJAX calls, the full page otherwise.
    public async Task<IActionResult> Search(string? term)
    {
        var products = string.IsNullOrWhiteSpace(term)
            ? await _uow.Products.GetAllWithCategoryAsync()
            : await _uow.Products.SearchAsync(term.Trim());

        if (IsAjax) return PartialView("_ProductRows", products);

        ViewData["Term"] = term;
        return View("Index", products);
    }

    // GET /category/2/products   (route: "products-by-category")
    public async Task<IActionResult> ByCategory(int categoryId)
    {
        var category = await _uow.Categories.GetByIdAsync(categoryId);
        if (category is null) return NotFound();

        ViewData["Title"] = $"Category: {category.Name}";
        return View("Index", await _uow.Products.GetByCategoryAsync(categoryId));
    }

    // GET /archive/2026/11   (route: "archive", with int constraints)
    public async Task<IActionResult> Archive(int year, int? month)
    {
        ViewData["Title"] = month.HasValue ? $"Added in {year}-{month:00}" : $"Added in {year}";
        return View("Index", await _uow.Products.GetByMonthAsync(year, month));
    }

    // GET /product/5/mechanical-keyboard   (route: "product-details")
    public async Task<IActionResult> Details(int id, string? slug)
    {
        var product = await _uow.Products.GetByIdWithCategoryAsync(id);
        if (product is null) return NotFound();

        // Canonical URL: if the slug is missing/wrong, redirect permanently to the right one
        if (!string.Equals(slug, product.Slug, StringComparison.OrdinalIgnoreCase))
            return RedirectToRoutePermanent("product-details", new { id = product.Id, slug = product.Slug });

        return View(product);
    }

    // GET /Products/Create
    public async Task<IActionResult> Create()
    {
        await LoadCategoriesAsync();
        return View(new Product());
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Product product)
    {
        ModelState.Remove(nameof(Product.Category));
        if (!ModelState.IsValid)
        {
            await LoadCategoriesAsync(product.CategoryId);
            return View(product);
        }

        product.CreatedAt = DateTime.UtcNow;
        await _uow.Products.AddAsync(product);
        await _uow.CompleteAsync();
        return RedirectToAction(nameof(Index));
    }

    // GET /Products/Edit/5
    public async Task<IActionResult> Edit(int id)
    {
        var product = await _uow.Products.GetByIdAsync(id);
        if (product is null) return NotFound();

        await LoadCategoriesAsync(product.CategoryId);
        return View(product);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Product product)
    {
        if (id != product.Id) return BadRequest();

        ModelState.Remove(nameof(Product.Category));
        if (!ModelState.IsValid)
        {
            await LoadCategoriesAsync(product.CategoryId);
            return View(product);
        }

        _uow.Products.Update(product);
        await _uow.CompleteAsync();
        return RedirectToAction(nameof(Index));
    }

    // POST /Products/Delete/5  -- called with AJAX (fetch) from the Index page
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id)
    {
        var product = await _uow.Products.GetByIdAsync(id);
        if (product is null) return NotFound(new { success = false, message = "Product not found." });

        _uow.Products.Remove(product);
        await _uow.CompleteAsync();
        return Json(new { success = true, message = $"'{product.Name}' deleted." });
    }

    private async Task LoadCategoriesAsync(int? selectedId = null)
    {
        var categories = await _uow.Categories.GetAllAsync();
        ViewBag.Categories = new SelectList(categories, "Id", "Name", selectedId);
    }
}
