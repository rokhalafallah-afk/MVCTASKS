// AJAX demo (no page reload):
//  1) live search  -> GET  /search?term=...   returns an HTML partial (table rows)
//  2) delete       -> POST /Products/Delete/5 returns JSON { success, message }

(() => {
    const searchBox = document.getElementById('searchBox');
    const rows = document.getElementById('productRows');
    const alertBox = document.getElementById('alertBox');
    const token = document.querySelector('input[name="__RequestVerificationToken"]')?.value;

    // --- 1) Live search with a small debounce ---------------------------------
    let timer;
    searchBox?.addEventListener('input', () => {
        clearTimeout(timer);
        timer = setTimeout(async () => {
            const url = `${searchBox.dataset.url}?term=${encodeURIComponent(searchBox.value)}`;
            try {
                const response = await fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
                if (!response.ok) throw new Error(`HTTP ${response.status}`);
                rows.innerHTML = await response.text();
            } catch (err) {
                showAlert('danger', `Search failed: ${err.message}`);
            }
        }, 300);
    });

    // --- 2) Delete (event delegation so it also works on rows loaded by AJAX) --
    rows?.addEventListener('click', async (e) => {
        const button = e.target.closest('.js-delete');
        if (!button) return;
        if (!confirm('Delete this product?')) return;

        try {
            const response = await fetch(`/Products/Delete/${button.dataset.id}`, {
                method: 'POST',
                headers: { 'RequestVerificationToken': token, 'X-Requested-With': 'XMLHttpRequest' }
            });
            const result = await response.json();
            if (result.success) {
                button.closest('tr').remove();
                showAlert('success', result.message);
            } else {
                showAlert('danger', result.message);
            }
        } catch (err) {
            showAlert('danger', `Delete failed: ${err.message}`);
        }
    });

    function showAlert(type, message) {
        alertBox.innerHTML = `<div class="alert alert-${type} alert-dismissible fade show">${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>`;
    }
})();
