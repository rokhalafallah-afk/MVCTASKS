using Microsoft.EntityFrameworkCore;
using StoreApp.Models;

namespace StoreApp.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Product> Products => Set<Product>();
    public DbSet<Category> Categories => Set<Category>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Category>().HasData(
            new Category { Id = 1, Name = "Keyboards" },
            new Category { Id = 2, Name = "Monitors" },
            new Category { Id = 3, Name = "Accessories" });

        modelBuilder.Entity<Product>().HasData(
            new Product { Id = 1, Name = "Mechanical Keyboard", Price = 89.99m, CategoryId = 1, CreatedAt = new DateTime(2026, 9, 5) },
            new Product { Id = 2, Name = "Wireless Keyboard", Price = 49.50m, CategoryId = 1, CreatedAt = new DateTime(2026, 10, 12) },
            new Product { Id = 3, Name = "27 inch Monitor", Price = 249.00m, CategoryId = 2, CreatedAt = new DateTime(2026, 10, 20) },
            new Product { Id = 4, Name = "USB-C Hub", Price = 34.90m, CategoryId = 3, CreatedAt = new DateTime(2026, 11, 3) },
            new Product { Id = 5, Name = "Ergonomic Mouse", Price = 39.00m, CategoryId = 3, CreatedAt = new DateTime(2026, 11, 15) });
    }
}
