# StoreApp: Repository + DI, custom routes, AJAX

## Run

1. Open `StoreApp.sln` in Visual Studio 2022 (.NET 8 SDK).
2. Press F5. In Development it uses LocalDB (`appsettings.Development.json`) and creates and seeds the database automatically.
3. For a real SQL Server, don't edit the JSON; run:
   `dotnet user-secrets set "ConnectionStrings:DefaultConnection" "<your string>"`

## Layout

| Folder | Purpose |
|---|---|
| `Models/` | `Product`, `Category` |
| `Data/` | `AppDbContext` (+ seed data) |
| `Repositories/` | `IRepository<T>`, `Repository<T>`, product/category repositories, `IUnitOfWork` |
| `Extensions/` | `AddInfrastructure`: all DI registrations (composition root) |
| `Controllers/` | Thin controllers that depend only on `IUnitOfWork` |
| `Program.cs` | Pipeline + custom routes |
| `Docs/` | Task 3/4/5/6 write-ups and the two LinkedIn articles |

## Task map

1. Repository + DI: `Repositories/`, `Extensions/ServiceCollectionExtensions.cs`, `Controllers/`
2. Custom routes: `Program.cs`
3. Article: `Docs/LinkedIn_Article_Dependency_Injection.md`
4. Connection string security: `Docs/Task4_Task5_Answers.md`, `Program.cs`, `appsettings*.json`
5. AJAX: `Docs/Task4_Task5_Answers.md`, `wwwroot/js/products.js`
6. Article: `Docs/LinkedIn_Article_Creational_Design_Patterns.md`
