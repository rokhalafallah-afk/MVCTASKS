# Dependency Injection in ASP.NET Core: stop using `new` everywhere

If your controller creates its own database class with `new`, you have quietly welded two pieces of code together. Change one, and the other breaks. Test one, and you must run both.

Dependency Injection (DI) is the fix, and in ASP.NET Core you don't even have to install anything. It is built in.

## The problem

```csharp
public class ProductsController : Controller
{
    private readonly ProductRepository _repo = new ProductRepository(new AppDbContext());
}
```

This controller decides *which* repository to use, *how* to build it and *how long* it lives. It can't be unit-tested without a real database, and swapping implementations means editing every class that uses it.

## The idea

A class should **ask for what it needs** and let someone else supply it.

```csharp
public class ProductsController : Controller
{
    private readonly IUnitOfWork _uow;
    public ProductsController(IUnitOfWork uow) => _uow = uow;   // constructor injection
}
```

The controller now depends on an **abstraction** (`IUnitOfWork`), not a concrete class. This is the "D" in SOLID: depend on abstractions, not details.

## Where the wiring lives

ASP.NET Core ships with a built-in container. You register services once, in `Program.cs`:

```csharp
services.AddDbContext<AppDbContext>(o => o.UseSqlServer(connectionString));
services.AddScoped<IProductRepository, ProductRepository>();
services.AddScoped<IUnitOfWork, UnitOfWork>();
```

The framework builds the whole chain for you: Controller → UnitOfWork → Repositories → DbContext. You never write `new` for any of them.

## The three lifetimes (the part everyone gets wrong)

- **Transient**: a new instance every time it is requested. Good for lightweight, stateless services.
- **Scoped**: one instance per HTTP request. The right choice for `DbContext` and repositories, so every class in a request shares the same unit of work.
- **Singleton**: one instance for the whole application. Good for caches and configuration, but must be thread-safe.

A classic bug: injecting a Scoped service into a Singleton. The Singleton keeps it alive forever, and your `DbContext` is now shared across requests. ASP.NET Core catches this in Development with scope validation.

## Why it matters

1. **Testability:** pass a fake `IProductRepository` in a unit test, no database needed.
2. **Flexibility:** switch from SQL Server to another store by changing one registration line.
3. **Cleaner code:** classes declare their dependencies openly in the constructor, so a class with 9 parameters is telling you it does too much.
4. **Centralised configuration:** lifetimes and implementations are decided in one place.

## Pairing DI with the Repository pattern

Repository hides *how* data is stored. DI delivers the repository to whoever needs it. Together, controllers contain only request-handling logic, and data access can be replaced or mocked freely.

## Takeaways

- Constructor injection is the default. Prefer it over service-locator calls like `GetService<T>()`.
- Register interfaces, inject interfaces.
- Pick lifetimes deliberately: DbContext is Scoped.
- Keep all registrations in one extension method, a "composition root".

How do you organise your service registrations: one big `Program.cs` or extension methods per feature? I'd like to hear in the comments.

#dotnet #aspnetcore #csharp #dependencyinjection #cleanarchitecture #softwaredevelopment
