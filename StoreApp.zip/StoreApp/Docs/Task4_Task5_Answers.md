# Task 4 – Securing a hard-coded connection string

**The problem:** a connection string written in `appsettings.json` (or worse, in C# code) gets committed to Git, copied to every machine, and leaks the database password to anyone who can read the repo.

The project already applies the idea: `appsettings.json` holds an **empty** value, and `AddInfrastructure` reads `ConnectionStrings:DefaultConnection` from the layered configuration system and fails fast if it is missing.

## Approach 1 – User Secrets (development)

Stored in your user profile, outside the project folder, so it can never be committed.

```bash
cd StoreApp
dotnet user-secrets init        # already done: UserSecretsId is in the .csproj
dotnet user-secrets set "ConnectionStrings:DefaultConnection" "Server=.;Database=StoreAppDb;User Id=app;Password=S3cr3t!;TrustServerCertificate=True"
```

No code change is needed: in the Development environment, `WebApplication.CreateBuilder` already loads user secrets.
Limitation: development only, and secrets are stored unencrypted on your machine.

## Approach 2 – Environment variables (staging / production / Docker / CI)

The server or container injects the value at runtime. Double underscore `__` replaces `:`.

```bash
# Linux / macOS
export ConnectionStrings__DefaultConnection="Server=db;Database=StoreAppDb;User Id=app;Password=...;"

# Windows PowerShell
$env:ConnectionStrings__DefaultConnection = "Server=db;..."
```

Azure App Service "Connection strings" settings, Docker `-e`, and Kubernetes Secrets all work this way.
Environment variables override `appsettings.json`, so there is no code change either.

## Approach 3 – A secret manager such as Azure Key Vault (production, best)

Secrets are encrypted, audited, rotatable, and access is controlled by identity, not by passwords sitting in config.

```csharp
builder.Configuration.AddAzureKeyVault(
    new Uri(builder.Configuration["KeyVault:Uri"]!),
    new DefaultAzureCredential());      // Managed Identity in Azure, your login locally
```

Create a secret named `ConnectionStrings--DefaultConnection` (`--` maps to `:`). The commented block in `Program.cs` and the `.csproj` shows exactly where this goes.

## Bonus – avoid the password altogether

Use **Windows Integrated Security** (`Trusted_Connection=True`) on-premises, or **Managed Identity** with Azure SQL (`Authentication=Active Directory Default`). A connection string with no password is nothing to steal, which is why `appsettings.Development.json` (LocalDB) is safe to commit.

| Approach | Best for | Encrypted at rest | Code change |
|---|---|---|---|
| User Secrets | Local development | No (user profile) | None |
| Environment variables | Docker, CI/CD, App Service | Depends on host | None |
| Key Vault | Production | Yes, audited and rotatable | A few lines |

---

# Task 5 (Bonus) – AJAX

**AJAX** (Asynchronous JavaScript And XML) is a technique where the browser sends an HTTP request in the background with JavaScript (`fetch` / `XMLHttpRequest` / jQuery) and updates **part** of the page with the response, without a full page reload. Today the payload is usually JSON or an HTML fragment rather than XML.

## 3 reasons to use it in MVC apps

1. **Better user experience:** only the changed part of the page is refreshed, so there is no flicker, no lost scroll position and no lost form state.
2. **Less bandwidth and faster responses:** the server returns a small partial view (`_ProductRows`) or JSON instead of the whole layout, CSS and scripts again.
3. **Interactivity without a full SPA:** live search, inline delete, cascading dropdowns and validation checks can be added to normal Razor views while keeping server-side rendering and the MVC structure.

## The demo in this solution

| Feature | Request | Server returns |
|---|---|---|
| Live search box on `/Products` | `GET /search?term=key` | `PartialView("_ProductRows")`, which JS injects into the table |
| Delete button | `POST /Products/Delete/5` with anti-forgery header | `Json(new { success, message })`, and JS removes the row |

Code: `Controllers/ProductsController.cs` (`Search`, `Delete`), `Views/Products/_ProductRows.cshtml`, `wwwroot/js/products.js`.
Note the `X-Requested-With` header: the `Search` action uses it to return the partial for AJAX calls and the full page for normal browser navigation.
