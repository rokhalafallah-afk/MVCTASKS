# Creational Design Patterns: who creates your objects, and why it matters

Every object in your application has to be created by *someone*. Creational design patterns answer one question: **how do we create objects without tightly coupling our code to concrete classes?**

When `new` is scattered everywhere, code becomes rigid. Creational patterns put object creation behind a well-defined mechanism, so the rest of the code asks for an object without caring how it is built.

## The five classic creational patterns (Gang of Four)

### 1. Singleton
Guarantees **one instance** with a global access point. Examples: configuration, logging, cache.

```csharp
public sealed class AppSettings
{
    private static readonly Lazy<AppSettings> _instance = new(() => new AppSettings());
    public static AppSettings Instance => _instance.Value;
    private AppSettings() { }
}
```
Caution: hand-written singletons hide dependencies and hurt testing. In ASP.NET Core, prefer `AddSingleton<T>()` and let the container manage it.

### 2. Factory Method
Defines an interface for creating an object but lets **subclasses or a method decide which class** to instantiate.

```csharp
public static class ShapeFactory
{
    public static IShape Create(string type) => type switch
    {
        "circle" => new Circle(),
        "square" => new Square(),
        _ => throw new ArgumentException("Unknown shape")
    };
}
```
Use it when the exact type is only known at runtime.

### 3. Abstract Factory
Creates **families of related objects** without naming their concrete classes, for example `WindowsButton` + `WindowsCheckbox` versus `MacButton` + `MacCheckbox` from a `IUiFactory`.

### 4. Builder
Constructs a **complex object step by step**, separating construction from representation. You use it daily:

```csharp
var app = WebApplication.CreateBuilder(args);   // builder pattern
```
Great when an object has many optional parts (HTTP requests, SQL queries, reports).

### 5. Prototype
Creates new objects by **cloning an existing one**. Useful when construction is expensive and a copy with small changes is cheaper (deep copy vs shallow copy matters here!).

## Quick comparison

| Pattern | Core idea | Typical use |
|---|---|---|
| Singleton | One instance only | Config, logging |
| Factory Method | Decide the type at one place | Plugins, parsers |
| Abstract Factory | Families of related objects | UI themes, cross-platform |
| Builder | Step-by-step construction | Complex configuration |
| Prototype | Clone instead of create | Expensive objects |

## Is Dependency Injection a creational pattern?

Strictly, **no**: DI is not one of the five GoF patterns. It is a form of **Inversion of Control** and a design technique. But if we look at its *purpose*, it is creational in spirit: it moves object creation out of the consumer, which is exactly what Factory and Abstract Factory do.

You can think of the DI container as a **smart, configurable factory** that:
- creates objects for you (Factory),
- controls how many instances exist through lifetimes (Singleton / Scoped / Transient),
- builds entire dependency graphs automatically.

In ASP.NET Core, `AddSingleton` is the Singleton pattern managed by the container, and the container itself is a generalised Abstract Factory. So treating DI as "creational" is a helpful mental model, even if it is not part of the original catalogue.

## When to use what

- Need just one shared instance → let the **DI container** manage a Singleton.
- Type depends on runtime input → **Factory**.
- Object has a long list of optional settings → **Builder**.
- Creating expensive copies → **Prototype**.
- Related families that must stay consistent → **Abstract Factory**.

## Takeaway

Creational patterns are not about memorising UML. They are about one habit: **separate creating an object from using it**. Master that, and DI, factories and builders all feel like the same idea in different clothes.

Which creational pattern do you use most in your projects? Tell me below.

#designpatterns #csharp #dotnet #softwarearchitecture #cleancode #dependencyinjection
